from tkinter import *
import server
import sqlite3


tela = Tk()
tela.title('Cadastros')
tela['bg'] = 'white'


def enviar():
    conect = sqlite3.connect('cadastro.db')
    cursor = conect.cursor()
    nome_db = nome.get()
    cpf_db = cpf.get()
    email_db = email.get()
    cursor.execute("""
    INSERT INTO cliente(nome,cpf, email)
    VALUES (?,?,?)
    """,(nome_db,cpf_db,email_db))
    conect.commit()
    conect.close()

def mostra():
    conect = sqlite3.connect('cadastro.db')
    cursor = conect.cursor()
    cursor.execute("""
    SELECT nome,cpf,email FROM cliente;
    """)
    dados = cursor.fetchall()
    for linha in dados:
        nomem  ['text']  = 'Nome  : '+linha[0]
        cpfm   ['text']  = 'CPF   : '+linha[1]
        emailm ['text']  = 'Email : '+linha[2]





nomet = Label(tela, text='Nome')
nomet.place(x=50,y=100)
nome = Entry()
nome.place(x=50,y=120)


cpft = Label(tela, text='CPF')
cpft.place(x=50,y=140)
cpf = Entry()
cpf.place(x=50,y=160)

emailt = Label(tela, text='Email')
emailt.place(x=50,y=180)
email = Entry()
email.place(x=50,y=200)


enviar = Button(tela, text='Enviar', command=enviar)
enviar.place(x=50,y=250)


consul = Button(tela, text='Confere', command=mostra)
consul.place(x=50,y=550)

nomem = Label(tela, text='Consulta')
nomem.place(x=50,y=400)
cpfm = Label(tela, text='Consulta')
cpfm.place(x=50,y=450)
emailm = Label(tela, text='Consulta')
emailm.place(x=50,y=500)






tela.geometry('300x600+500+500')
tela.mainloop()
