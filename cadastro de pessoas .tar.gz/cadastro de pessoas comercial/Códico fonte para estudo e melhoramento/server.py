import sqlite3

def cria():
    conect = sqlite3.connect('cadastro.db')
    cursor = conect.cursor()
    cursor.execute("""
    CREATE TABLE cliente (
    id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    cpf     VARCHAR(11) NOT NULL,
    email TEXT NOT NULL
    );
    """)
    conect.close()
